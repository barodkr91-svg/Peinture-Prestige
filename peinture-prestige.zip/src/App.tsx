import { useState } from "react";
import { motion } from "framer-motion";
import { Paintbrush, Phone, Mail, Calendar, Star, CheckCircle, Instagram, Facebook, MapPin, Clock, ChevronDown } from "lucide-react";

// --- Utilitaires simples ---
const SectionTitle = ({ kicker, title, subtitle }: { kicker?: string; title: string; subtitle?: string }) => (
  <div className="max-w-2xl mx-auto text-center mb-10">
    {kicker && <p className="text-sm uppercase tracking-widest text-primary/80 font-semibold">{kicker}</p>}
    <h2 className="text-3xl md:text-4xl font-bold mt-2">{title}</h2>
    {subtitle && <p className="text-muted-foreground mt-3">{subtitle}</p>}
  </div>
);

const Badge = ({ children }: { children: React.ReactNode }) => (
  <span className="inline-flex items-center gap-2 rounded-full border px-3 py-1 text-sm bg-white/60 backdrop-blur shadow-sm">
    <CheckCircle className="w-4 h-4" /> {children}
  </span>
);

const FAQItem = ({ q, a }: { q: string; a: string }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="border rounded-2xl p-4 bg-white/70">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between text-left">
        <span className="font-semibold pr-6">{q}</span>
        <ChevronDown className={`w-5 h-5 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && <p className="text-muted-foreground mt-3">{a}</p>}
    </div>
  );
};

// --- Page principale ---
export default function App() {
  return (
    <div className="min-h-screen text-slate-800 bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Barre d'annonce */}
      <div className="w-full bg-primary/10 text-primary text-center text-sm py-2">Devis gratuit sous 24h • Déplacements en Île-de-France</div>

      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><Paintbrush className="w-6 h-6 text-primary" /></div>
            <div>
              <p className="font-bold text-lg leading-tight">Peinture Prestige</p>
              <p className="text-xs text-muted-foreground -mt-1">Entreprise de peinture</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#services" className="hover:text-primary">Services</a>
            <a href="#realisations" className="hover:text-primary">Réalisations</a>
            <a href="#avis" className="hover:text-primary">Avis</a>
            <a href="#contact" className="hover:text-primary">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <a href="tel:+33600000000" className="hidden sm:inline-flex items-center gap-2 rounded-xl bg-primary text-white px-4 py-2 shadow hover:opacity-90">
              <Phone className="w-4 h-4" /> 06 00 00 00 00
            </a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 opacity-10" style={{
          backgroundImage:
            "radial-gradient(40rem 20rem at 20% 10%, rgba(212,175,55,.35) 0%, transparent 60%)," +
            "radial-gradient(30rem 18rem at 80% 20%, rgba(212,175,55,.25) 0%, transparent 60%)",
        }} />
        <div className="max-w-6xl mx-auto px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              Finitions **prestige** pour vos <span className="text-primary">murs</span> & plafonds
            </h1>
            <p className="text-lg text-muted-foreground mt-4">
              Peinture intérieure & extérieure, enduits décoratifs, ravalement de façade et
              finitions premium pour particuliers et professionnels.
            </p>
            <div className="flex flex-wrap items-center gap-3 mt-6">
              <Badge>Garantie décennale</Badge>
              <Badge>Propreté du chantier</Badge>
              <Badge>Matériaux éco-responsables</Badge>
            </div>
            <div className="flex flex-wrap gap-3 mt-8">
              <a href="#devis" className="inline-flex items-center gap-2 rounded-xl bg-primary text-white px-5 py-3 shadow">
                <Calendar className="w-4 h-4" /> Demander un devis
              </a>
              <a href="mailto:contact@peintureprestige.fr" className="inline-flex items-center gap-2 rounded-xl border px-5 py-3">
                <Mail className="w-4 h-4" /> contact@peintureprestige.fr
              </a>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}>
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl bg-white">
              {/* Mockup galerie */}
              <div className="grid grid-cols-3 gap-1 h-full">
                <div className="bg-[url('https://images.unsplash.com/photo-1501045661006-fcebe0257c3f?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center" />
                <div className="bg-[url('https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center" />
                <div className="bg-[url('https://images.unsplash.com/photo-1503387762-592deb58ef4e?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center" />
                <div className="col-span-2 bg-[url('https://images.unsplash.com/photo-1484154218962-a197022b5858?q=80&w=1200&auto=format&fit=crop')] bg-cover bg-center" />
                <div className="bg-[url('https://images.unsplash.com/photo-1459535653751-d571815e906b?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center" />
                <div className="bg-[url('https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center" />
                <div className="col-span-2 bg-[url('https://images.unsplash.com/photo-1501676491271-50d4b3b5d56f?q=80&w=1200&auto=format&fit=crop')] bg-cover bg-center" />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="max-w-6xl mx-auto px-4 py-16">
        <SectionTitle kicker="Nos services" title="Peinture & finitions haut de gamme" subtitle="Un accompagnement de A à Z, du choix des teintes à la remise des clés." />
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              title: "Peinture intérieure",
              desc: "Murs, plafonds, boiseries — finitions mates, satinées ou velours.",
            },
            {
              title: "Peinture extérieure",
              desc: "Façades, volets, ferronneries — protection durable contre les intempéries.",
            },
            {
              title: "Décoration & enduits",
              desc: "Tadelakt, effet béton, chaux — textures uniques pour un rendu artisanal.",
            },
            {
              title: "Préparation des supports",
              desc: "Ponçage, rebouchage, lissage — la clé d’un résultat impeccable.",
            },
            {
              title: "Conseil couleur",
              desc: "Nuanciers, échantillons et simulation 3D pour choisir sereinement.",
            },
            {
              title: "Locaux pros",
              desc: "Bureaux, commerces, copropriétés — planning adapté et délais tenus.",
            },
          ].map((s, i) => (
            <div key={i} className="rounded-2xl border bg-white/70 p-6 shadow-sm hover:shadow-md transition">
              <h3 className="font-semibold text-lg">{s.title}</h3>
              <p className="text-muted-foreground mt-2">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Réalisations */}
      <section id="realisations" className="bg-white/70 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <SectionTitle kicker="Portfolio" title="Quelques réalisations" subtitle="Un aperçu de nos derniers chantiers livrés." />
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div key={n} className="group rounded-2xl overflow-hidden border bg-white shadow-sm">
                <div className={`aspect-[4/3] bg-cover bg-center`} style={{ backgroundImage: `url(https://picsum.photos/seed/paint${n}/800/600)` }} />
                <div className="p-4">
                  <p className="font-semibold">Appartement — Paris {n}ᵉ</p>
                  <p className="text-sm text-muted-foreground">Peinture intérieure, teintes minérales</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Avis */}
      <section id="avis" className="max-w-6xl mx-auto px-4 py-16">
        <SectionTitle kicker="Témoignages" title="Plébiscité par nos clients" subtitle="Moyenne 4,9/5 sur plus de 120 avis vérifiés." />
        <div className="grid md:grid-cols-3 gap-6">
          {["Travail minutieux et propre, délais respectés.", "Excellents conseils couleurs, rendu magnifique !", "Très pro pour notre boutique, planning nocturne nickel."].map((t, i) => (
            <div key={i} className="rounded-2xl border bg-white/70 p-6 shadow-sm">
              <div className="flex items-center gap-1 text-yellow-500 mb-3">
                {Array.from({ length: 5 }).map((_, j) => <Star key={j} className="w-4 h-4 fill-current" />)}
              </div>
              <p className="">{t}</p>
              <p className="mt-3 text-sm text-muted-foreground">— Marie D.</p>
            </div>
          ))}
        </div>
      </section>

      {/* Devis / Contact */}
      <section id="devis" className="bg-gradient-to-br from-primary/10 to-emerald-100/40 py-16">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <SectionTitle title="Demandez votre devis gratuit" subtitle="Réponse sous 24h, déplacement et conseils offerts." />
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Envoyez-nous des photos ou un plan rapide</li>
              <li>• Précisez les surfaces (m²) et le type de pièces</li>
              <li>• Nous proposons jusqu’à 3 options de finition</li>
            </ul>
            <div className="flex gap-3 mt-6">
              <a href="tel:+33600000000" className="inline-flex items-center gap-2 rounded-xl bg-primary text-white px-5 py-3 shadow"><Phone className="w-4 h-4" /> Appeler</a>
              <a href="mailto:contact@peintureprestige.fr" className="inline-flex items-center gap-2 rounded-xl border px-5 py-3"><Mail className="w-4 h-4" /> Envoyer un email</a>
            </div>
          </div>
          <form id="contact" onSubmit={(e)=>e.preventDefault()} className="rounded-3xl border bg-white p-6 shadow-sm">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm">Nom</label>
                <input required className="mt-1 w-full rounded-xl border px-3 py-2" placeholder="Votre nom" />
              </div>
              <div>
                <label className="text-sm">Téléphone</label>
                <input required className="mt-1 w-full rounded-xl border px-3 py-2" placeholder="06…" />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm">Email</label>
                <input type="email" className="mt-1 w-full rounded-xl border px-3 py-2" placeholder="vous@exemple.com" />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm">Message</label>
                <textarea className="mt-1 w-full rounded-xl border px-3 py-2 h-28" placeholder="Décrivez votre projet (surfaces, délais, style)…" />
              </div>
            </div>
            <button className="mt-4 w-full rounded-xl bg-primary text-white px-5 py-3 shadow">Obtenir mon devis</button>
            <p className="text-xs text-muted-foreground mt-2">En envoyant ce formulaire, vous acceptez notre <a className="underline" href="#">politique de confidentialité</a>.</p>
          </form>
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <SectionTitle kicker="FAQ" title="Questions fréquentes" />
        <div className="grid md:grid-cols-2 gap-4">
          <FAQItem q="Quels délais pour un chantier standard ?" a="Sous 7 à 10 jours selon la surface et la préparation des supports. Un planning express est possible." />
          <FAQItem q="Travaillez-vous le week-end ou de nuit ?" a="Oui, pour les locaux pros nous adaptons les horaires afin de limiter l'impact sur votre activité." />
          <FAQItem q="Quelles marques de peinture utilisez-vous ?" a="Nous privilégions des peintures professionnelles à faible COV (Farrow & Ball, Little Greene, Seigneurie, Tollens)." />
          <FAQItem q="Intervenez-vous hors Île-de-France ?" a="Nous étudions les projets importants partout en France, sur devis personnalisé." />
        </div>
      </section>

      {/* Bandeau social / coordonnées */}
      <section className="py-10 border-t bg-white/70">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4" /> Île-de-France
            <Clock className="w-4 h-4" /> 8:00 — 19:00
          </div>
          <div className="flex items-center gap-3">
            <a aria-label="Instagram" href="#" className="rounded-xl border p-2 hover:bg-slate-50"><Instagram className="w-5 h-5" /></a>
            <a aria-label="Facebook" href="#" className="rounded-xl border p-2 hover:bg-slate-50"><Facebook className="w-5 h-5" /></a>
            <a href="tel:+33600000000" className="inline-flex items-center gap-2 rounded-xl bg-primary text-white px-4 py-2 shadow"><Phone className="w-4 h-4" /> 06 00 00 00 00</a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-3 gap-6 text-sm">
          <div>
            <p className="font-semibold">Peinture Prestige</p>
            <p className="text-muted-foreground mt-2">SIREN 123 456 789 — Assurance décennale — Mentions légales</p>
          </div>
          <div>
            <p className="font-semibold">Navigation</p>
            <ul className="mt-2 space-y-1">
              <li><a href="#services" className="hover:underline">Services</a></li>
              <li><a href="#realisations" className="hover:underline">Réalisations</a></li>
              <li><a href="#avis" className="hover:underline">Avis</a></li>
              <li><a href="#devis" className="hover:underline">Devis</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold">Contact</p>
            <ul className="mt-2 space-y-1">
              <li><a href="mailto:contact@peintureprestige.fr" className="hover:underline">contact@peintureprestige.fr</a></li>
              <li><a href="tel:+33600000000" className="hover:underline">06 00 00 00 00</a></li>
              <li>Île-de-France</li>
            </ul>
          </div>
        </div>
        <p className="text-center text-xs text-muted-foreground mt-8">© {new Date().getFullYear()} Peinture Prestige — Tous droits réservés.</p>
      </footer>
    </div>
  );
}
