# Peinture Prestige — Site vitrine (React + Vite + Tailwind)

## Déploiement par **Upload** sur Vercel (sans Git)
1. Allez sur https://vercel.com → Add New → Project → Import Project → **Upload**.
2. Glissez ce dossier **zippé**.
3. Vercel détectera *Framework: Vite* et construira le site.
4. Cliquez **Deploy** → votre lien en ligne sera prêt.

Aucune configuration supplémentaire n’est requise.
